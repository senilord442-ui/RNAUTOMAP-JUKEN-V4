package com.rnautomap.juken;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status; private WebView web; private BroadcastReceiver liveReceiver;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10,10,10)); getWindow().setNavigationBarColor(Color.rgb(10,10,10));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(10,10,10)); root.setFitsSystemWindows(true);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(6),dp(8),dp(6)); bar.setMinimumHeight(dp(64));
        status=new TextView(this); status.setText("MOTOR BELUM TERHUBUNG · menunggu JUKEN Live"); status.setTextColor(Color.WHITE); status.setTextSize(12); status.setGravity(Gravity.CENTER_VERTICAL); status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(48),1); sp.setMargins(0,0,dp(6),0); bar.addView(status,sp);
        Button reader=new Button(this); reader.setText("PEMBACA"); reader.setTextSize(10); reader.setSingleLine(true); reader.setOnClickListener(v->openAccessibility()); bar.addView(reader,new LinearLayout.LayoutParams(dp(90),dp(48)));
        Button juken=new Button(this); juken.setText("BUKA JUKEN"); juken.setTextSize(10); juken.setSingleLine(true); juken.setOnClickListener(v->openJuken()); bar.addView(juken,new LinearLayout.LayoutParams(dp(92),dp(48)));
        root.addView(bar);
        web=new WebView(this); WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){openExternal(r.getUrl().toString());return true;} @Override public boolean shouldOverrideUrlLoading(WebView v,String u){openExternal(u);return true;}});
        web.addJavascriptInterface(new JsBridge(),"JukenBT"); web.loadUrl("file:///android_asset/kalkulator-peta-ecu.html"); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        liveReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
            if(!"com.rnautomap.juken.JUKEN_LIVE".equals(i.getAction()))return;
            boolean hr=i.hasExtra("rpm"),ht=i.hasExtra("tps"),ha=i.hasExtra("afr"); double rpm=i.getDoubleExtra("rpm",0),tps=i.getDoubleExtra("tps",0),afr=i.getDoubleExtra("afr",0); String raw=i.getStringExtra("raw");
            if(hr||ht||ha){String json=String.format(Locale.US,"{\"rpm\":%.0f,\"tps\":%.2f,\"afr\":%.3f,\"raw\":\"%s\"}",rpm,tps,afr,escape(raw==null?"":raw)); web.evaluateJavascript("window.onJukenLive&&window.onJukenLive("+json+")",null); setStatus(String.format(Locale.US,"MOTOR TERHUBUNG · JUKEN LIVE · RPM %.0f · TPS %.1f%% · AFR %.2f",rpm,tps,afr));}
            else setStatus("JUKEN TERDETEKSI · menunggu RPM/TPS/AFR");
        }};
    }
    private void openAccessibility(){try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));setStatus("Aktifkan RNAUTOMAP Juken Companion di Aksesibilitas");}catch(Exception e){setStatus("Gagal membuka Aksesibilitas");}}
    private void openJuken(){try{Intent i=getPackageManager().getLaunchIntentForPackage("com.bintangracingteam.juken");if(i!=null){startActivity(i);setStatus("JUKEN asli dibuka · Bluetooth tetap dikelola JUKEN");}else setStatus("JUKEN asli tidak ditemukan");}catch(Exception e){setStatus("Gagal membuka JUKEN");}}
    private void openExternal(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}}
    private String escape(String v){return v.replace("\\","\\\\").replace("\"","\\\"").replace("\r","").replace("\n"," ");}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void setStatus(String v){runOnUiThread(()->status.setText(v));}
    public class JsBridge {
        @JavascriptInterface public boolean isConnected(){return JukenAccessibilityService.running;}
        @JavascriptInterface public void send(String command){}
        @JavascriptInterface public void openUrl(String u){if(u!=null&&(u.startsWith("http://")||u.startsWith("https://")))openExternal(u);}
        @JavascriptInterface public String consult(String symptom,String rpm,String tps,String plug){return localDiagnosis(symptom,rpm,tps,plug);}
    }
    private String localDiagnosis(String symptom,String rpm,String tps,String plug){String x=(symptom+" "+plug).toLowerCase(Locale.US);boolean lean=x.contains("kering")||x.contains("lean")||x.contains("ngempos")||x.contains("kurang bensin");boolean rich=x.contains("basah")||x.contains("rich")||x.contains("hitam")||x.contains("boros")||x.contains("bau bensin");String d,e;int f=0;if(lean){f=4;d="Gejala mengarah ke campuran cenderung miskin.";e="Uji koreksi fuel kecil sekitar +4%. Validasi dengan AFR.";}else if(rich){f=-4;d="Gejala mengarah ke campuran cenderung kaya.";e="Uji pengurangan fuel kecil sekitar -4%. Validasi dengan AFR.";}else{d="Data belum cukup untuk menentukan arah koreksi.";e="Masukkan AFR aktual, RPM, TPS dan kondisi busi.";}return String.format(Locale.US,"{\"diagnosis\":\"%s\",\"explanation\":\"%s\",\"fuelAdjustPercent\":%d}",escape(d),escape(e),f);}
    @Override protected void onResume(){super.onResume();try{IntentFilter f=new IntentFilter("com.rnautomap.juken.JUKEN_LIVE");if(Build.VERSION.SDK_INT>=33)registerReceiver(liveReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(liveReceiver,f);}catch(Exception ignored){}if(JukenAccessibilityService.running)setStatus("PEMBACA AKTIF · buka JUKEN Live Data");}
    @Override protected void onPause(){try{unregisterReceiver(liveReceiver);}catch(Exception ignored){}super.onPause();}
}