RNAUTOMAP JUKEN V9
- JUKEN asli tetap menangani Bluetooth ECU.
- RNAUTOMAP membaca RPM/TPS/AFR yang terlihat dari JUKEN melalui Accessibility.
- Auto Tuning Live + 3D RPM x TPS.
- Koreksi sesi ditampilkan pada Fuel Correction workflow.
- Tidak ada direct ECU write protocol.
- V9 adalah companion; validasi live data di perangkat tetap diperlukan.
