package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT=77;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private TextView status; private WebView web;
    private long packetCounter=0;
    private volatile boolean liveRequested=false;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Window w=getWindow();
        w.setStatusBarColor(Color.rgb(13,13,13));
        w.setNavigationBarColor(Color.rgb(13,13,13));
        if(Build.VERSION.SDK_INT>=30){
            w.setDecorFitsSystemWindows(true);
        }
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(13,13,13)); root.setFitsSystemWindows(true);
        if(Build.VERSION.SDK_INT>=21){ root.setOnApplyWindowInsetsListener((v,insets)->{ int top=insets.getSystemWindowInsetTop(); int bottom=insets.getSystemWindowInsetBottom(); v.setPadding(0,top,0,bottom); return insets; }); }
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(12,10,12,10);
        status=new TextView(this); status.setText("Bluetooth: belum tersambung"); status.setTextColor(Color.WHITE); status.setTextSize(13);
        bar.addView(status,new LinearLayout.LayoutParams(0,56,1));
        Button btn=new Button(this); btn.setText("CONNECT JUKEN"); btn.setOnClickListener(v->connectJuken());
        bar.addView(btn,new LinearLayout.LayoutParams(-2,56));
        Button stop=new Button(this); stop.setText("STOP"); stop.setOnClickListener(v->{sendRaw("160B\r\n"); setStatus("Live dihentikan");});
        bar.addView(stop,new LinearLayout.LayoutParams(-2,56));
        root.addView(bar);
        web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){ openExternal(req.getUrl().toString()); return true; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url){ openExternal(url); return true; }
        });
        web.addJavascriptInterface(new JsBridge(),"JukenBT");
        web.loadUrl("file:///android_asset/kalkulator-peta-ecu.html");
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT);
    }

    private void openExternal(String url){
        try {
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch(Exception ignored) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored2) {}
        }
    }

    private void connectJuken(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT); return;
        }
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        if(a==null){setStatus("Bluetooth tidak tersedia");return;}
        if(!a.isEnabled()){setStatus("Nyalakan Bluetooth dulu");return;}
        BluetoothDevice target=null;
        for(BluetoothDevice d:a.getBondedDevices()){
            String n=d.getName(); if(n!=null&&(n.toUpperCase(Locale.US).contains("JUKEN")||n.toUpperCase(Locale.US).contains("BRT"))){target=d;break;}
        }
        if(target==null){setStatus("BRT JUKEN tidak ditemukan di perangkat yang sudah dipair");return;}
        final BluetoothDevice dev=target; setStatus("Menghubungkan ke "+dev.getName()+"...");
        new Thread(()->{try{
            BluetoothSocket s=dev.createRfcommSocketToServiceRecord(SPP); s.connect(); socket=s; in=s.getInputStream(); out=s.getOutputStream();
            setStatus("Terhubung: "+dev.getName());
            liveRequested=true;
            sendRaw("160A\r\n");
            setStatus("Terhubung: "+dev.getName()+" · LIVE aktif");
            readLoop();
        }catch(Exception e){setStatus("Gagal konek: "+e.getMessage());closeBt();}}).start();
    }

    private void readLoop(){
        byte[] buf=new byte[4096]; StringBuilder line=new StringBuilder();
        try{int n;
            while(socket!=null&&socket.isConnected()&&(n=in.read(buf))>0){
                line.append(new String(buf,0,n,StandardCharsets.US_ASCII));
                int i;
                while((i=line.indexOf("\n"))>=0){
                    String m=line.substring(0,i).replace("\r","").trim();
                    line.delete(0,i+1);
                    if(!m.isEmpty()) parseAndDispatch(m);
                }
            }
        }catch(Exception e){setStatus("Koneksi terputus");}finally{closeBt();}
    }

    private void parseAndDispatch(String raw){
        int idx=raw.toLowerCase(Locale.US).indexOf("a603;");
        if(idx<0) return;
        String frame=raw.substring(idx); String[] p=frame.split(";");
        if(p.length<13) return;
        try{
            int tpsRaw=parseInt(p[1]), rpm=parseInt(p[4]);
            double bat=parseDouble(p[2]), eot=parseDouble(p[5])/10.0, afr=parseDouble(p[7]);
            double inj=parseDouble(p[9]), ign=parseDouble(p[10])/10.0, mapRaw=parseDouble(p[11]), iat=parseDouble(p[12])/10.0;
            int tps;
            if(tpsRaw<=0)tps=0; else if(tpsRaw==1)tps=5; else if(tpsRaw<=19)tps=tpsRaw*5-5; else tps=100;
            int mapPct=mappingMap(mapRaw*5.0/1023.0);
            String json=String.format(Locale.US,"{\"rpm\":%d,\"tps\":%d,\"afr\":%.3f,\"bat\":%.3f,\"eot\":%.2f,\"iat\":%.2f,\"inj\":%.2f,\"ign\":%.2f,\"map\":%d,\"raw\":\"%s\"}",rpm,tps,afr,bat,eot,iat,inj,ign,mapPct,jsEscape(frame));
            packetCounter++;
            runOnUiThread(()->web.evaluateJavascript("window.onJukenLive&&window.onJukenLive("+json+")",null));
        }catch(Exception e){
            // Ignore malformed frames, but keep the Bluetooth stream alive.
        }
    }
    private int parseInt(String s){return Integer.parseInt(s.trim());}
    private double parseDouble(String s){return Double.parseDouble(s.trim());}
    private int mappingMap(double v){
        if(v<0.3)return (int)((100*v)/3.0); if(v<0.6)return (int)(((100*(v-0.3))/3.0)+10);
        if(v<1.1)return (int)(((100*(v-0.6))/5.0)+20); if(v<1.7)return (int)(((100*(v-1.1))/6.0)+30);
        if(v<2.2)return (int)(((100*(v-1.7))/5.0)+40); if(v<2.7)return (int)(((100*(v-2.2))/5.0)+50);
        if(v<3.3)return (int)(((100*(v-2.7))/6.0)+60); if(v<3.8)return (int)(((100*(v-3.3))/5.0)+70);
        if(v<4.4)return (int)(((100*(v-3.8))/6.0)+80); if(v<4.9)return (int)(((100*(v-4.4))/5.0)+90); return 100;
    }
    private String jsEscape(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","").replace("\n"," ");}
    private synchronized void sendRaw(String s){try{if(out!=null){out.write(s.getBytes(StandardCharsets.US_ASCII)); out.flush();}}catch(Exception ignored){}}
    private void closeBt(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;in=null;out=null;}
    private void setStatus(String s){runOnUiThread(()->status.setText("Bluetooth: "+s));}
    private String localAi(String symptom,String rpm,String tps,String plug){
        String x=(symptom+" "+plug).toLowerCase(Locale.US);
        boolean lean=x.contains("kering")||x.contains("lean")||x.contains("ngempos")||x.contains("kurang bensin")||x.contains("putih");
        boolean rich=x.contains("basah")||x.contains("rich")||x.contains("hitam")||x.contains("boros")||x.contains("bau bensin");
        boolean ignition=x.contains("ngelitik")||x.contains("knocking")||x.contains("detonasi")||x.contains("ngelitik");
        int rmin=0,rmax=0,tmin=0,tmax=0; try{rmin=Integer.parseInt(rpm.replaceAll("[^0-9]",""));}catch(Exception ignored){} try{tmin=Integer.parseInt(tps.replaceAll("[^0-9]",""));}catch(Exception ignored){}
        if(rmin>0) rmax=rmin; if(tmin>0) tmax=tmin;
        int fuel=lean?6:(rich?-6:0); double ign=ignition?-2:0;
        String diagnosis=lean?"Gejala mengarah ke campuran terlalu miskin pada kondisi yang dilaporkan.":rich?"Gejala mengarah ke campuran terlalu kaya pada kondisi yang dilaporkan.":ignition?"Gejala mengarah ke kebutuhan pemeriksaan timing pengapian pada area yang dilaporkan.":"Gejala belum cukup spesifik untuk menentukan koreksi map secara pasti.";
        String explanation=lean?"Sebagai koreksi awal, area RPM/TPS yang dilaporkan dapat diuji dengan penambahan fuel kecil lalu divalidasi menggunakan AFR meter. Jangan menerapkan perubahan besar sekaligus.":rich?"Sebagai koreksi awal, area RPM/TPS yang dilaporkan dapat diuji dengan pengurangan fuel kecil lalu divalidasi menggunakan AFR meter. Pastikan masalah mekanis dan injektor juga diperiksa.":ignition?"Untuk gejala detonasi/ngelitik, jangan menambah advance. Pengurangan timing kecil hanya layak diuji setelah kondisi bahan bakar dan temperatur dipastikan normal.":"Data gejala perlu ditambah agar koreksi map tidak ditebak. Periksa AFR, busi, TPS, dan kondisi mesin sebelum mengubah map.";
        return String.format(Locale.US,"{\"diagnosis\":\"%s\",\"explanation\":\"%s\",\"isMappingIssue\":%s,\"rpmMin\":%s,\"rpmMax\":%s,\"tpsMin\":%s,\"tpsMax\":%s,\"fuelAdjustPercent\":%d,\"ignitionAdjustDeg\":%.1f}",jsEscape(diagnosis),jsEscape(explanation),(lean||rich||ignition)?"true":"false",rmin>0?String.valueOf(rmin):"null",rmax>0?String.valueOf(rmax):"null",tmin>0?String.valueOf(tmin):"null",tmax>0?String.valueOf(tmax):"null",fuel,ign);
    }

    public class JsBridge{
        @JavascriptInterface public void send(String c){sendRaw(c);}
        @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
        @JavascriptInterface public String consult(String symptom,String rpm,String tps,String plug){return localAi(symptom,rpm,tps,plug);}
        @JavascriptInterface public void openUrl(String url){ if(url!=null && (url.startsWith("https://") || url.startsWith("http://"))) openExternal(url); }
    }
    @Override protected void onDestroy(){sendRaw("160B\r\n");closeBt();super.onDestroy();}
}
