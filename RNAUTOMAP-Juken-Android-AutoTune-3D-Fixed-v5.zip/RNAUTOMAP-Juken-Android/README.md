# RNAUTOMAP — Juken Android

Build ini mempertahankan kalkulator RNAUTOMAP asli dan menambahkan Bluetooth Classic SPP untuk BRT Juken.

## Yang sudah diaktifkan
- Connect otomatis ke perangkat Bluetooth paired yang namanya mengandung `JUKEN` atau `BRT`.
- Live stream Juken memakai `160A` dan berhenti dengan `160B`.
- Parsing frame live `A603;...` berdasarkan format reverse-engineered yang terdokumentasi di project referensi.
- Live RPM, TPS, AFR, baterai, EOT, IAT, injector timing, ignition timing, MAP.
- Auto Tune berbasis AFR target RNAUTOMAP: koreksi fuel disimpan di `correctionMap`, dibatasi dan diterapkan bertahap.
- Sel RPM×TPS aktif ditandai di grafik 3D dan mode `AUTO TUNE 3D` menampilkan permukaan koreksi secara real-time.
- Tombol YouTube/TikTok dibuka melalui aplikasi/browser eksternal.

## Sengaja belum diaktifkan
- SEND MAP ke ECU. APK Juken asli yang diunggah memang memuat jalur `SendMapMappingFunctionLive` dan pesan `SEND MAP SUCCESS!`, tetapi byte-level payload write belum diverifikasi sehingga fitur tetap dikunci.
- GET MAP / sinkronisasi map ECU penuh. APK asli memuat `GetMapState` dan pesan `GET MAP SUCCESS!`; implementasi payload belum diaktifkan sebelum struktur paketnya tervalidasi.

## Referensi protokol
Format live `A603`, breakpoint TPS, SPP UUID, dan command `160A/160B` mengikuti reverse-engineering yang tersedia secara publik dan harus diuji lagi pada unit ECU target sebelum penggunaan serius.
