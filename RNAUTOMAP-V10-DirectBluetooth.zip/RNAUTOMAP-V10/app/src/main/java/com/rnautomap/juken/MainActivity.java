package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private static final int REQ_BT=77;
  private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  private BluetoothAdapter adapter; private BluetoothSocket socket; private InputStream in; private OutputStream out;
  private WebView web; private final AtomicBoolean stopRead=new AtomicBoolean(false); private BroadcastReceiver receiver;

  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.setBackgroundColor(0xff02080d); web.addJavascriptInterface(new JsBridge(),"JukenBT"); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/kalkulator-peta-ecu.html"); requestBt();}
  private void requestBt(){ if(Build.VERSION.SDK_INT>=31 && (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED)) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT); }
  private boolean allowed(){return Build.VERSION.SDK_INT<31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED);}
  private BluetoothAdapter getAdapter(){if(adapter==null)adapter=BluetoothAdapter.getDefaultAdapter();return adapter;}
  private void jsState(boolean connected,String name,String msg){runOnUiThread(()->web.evaluateJavascript("window.onBtState&&window.onBtState("+jsonState(connected,name,msg)+")",null));}
  private String jsonState(boolean c,String n,String m){return "{\"connected\":"+c+",\"name\":\""+esc(n)+"\",\"message\":\""+esc(m)+"\"}";}
  private String esc(String s){if(s==null)return "";return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","").replace("\n","\\n");}
  private void emitRaw(String raw){String j="\""+esc(raw)+"\"";runOnUiThread(()->web.evaluateJavascript("window.onJukenRaw&&window.onJukenRaw("+j+")",null));}

  private String paired(){JSONArray a=new JSONArray(); if(!allowed())return a.toString(); BluetoothAdapter ad=getAdapter(); if(ad==null)return a.toString(); try{for(BluetoothDevice d:ad.getBondedDevices()){JSONObject o=new JSONObject();o.put("name",d.getName());o.put("address",d.getAddress());a.put(o);}}catch(Exception ignored){} return a.toString();}
  private void connect(String addr){if(!allowed()){requestBt();return;} BluetoothAdapter ad=getAdapter();if(ad==null){jsState(false,"","Bluetooth tidak tersedia");return;}if(!ad.isEnabled()){jsState(false,"","Nyalakan Bluetooth Android dulu");return;} final BluetoothDevice dev;try{dev=ad.getRemoteDevice(addr);}catch(Exception e){jsState(false,"","Alamat Bluetooth tidak valid");return;} new Thread(()->{closeSocket();jsState(false,devName(dev),"Menghubungkan…"); BluetoothSocket s=null;try{try{ad.cancelDiscovery();}catch(Exception ignored){} try{s=dev.createRfcommSocketToServiceRecord(SPP);s.connect();}catch(Exception e){try{if(s!=null)s.close();}catch(Exception ignored){} s=dev.createInsecureRfcommSocketToServiceRecord(SPP);s.connect();} socket=s;in=s.getInputStream();out=s.getOutputStream();stopRead.set(false);jsState(true,devName(dev),"CONNECTED • SPP"); readLoop();}catch(Exception e){try{if(s!=null)s.close();}catch(Exception ignored){}jsState(false,devName(dev),"Gagal konek: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}}).start();}
  private String devName(BluetoothDevice d){try{return d.getName()==null?d.getAddress():d.getName();}catch(Exception e){return d.getAddress();}}
  private void startLive(){sendRaw("160A\r\n");jsState(socket!=null&&socket.isConnected(),socket!=null?"JUKEN":"","LIVE request dikirim • raw data menunggu");}
  private void readLoop(){byte[] b=new byte[4096];ByteArrayOutputStream acc=new ByteArrayOutputStream();try{while(!stopRead.get()&&socket!=null&&socket.isConnected()){int n=in.read(b);if(n<=0)break;String chunk=new String(b,0,n,StandardCharsets.US_ASCII);emitRaw(chunk);acc.write(b,0,n);byte[] all=acc.toByteArray();int start=0;for(int i=0;i<all.length;i++){if(all[i]=='\n'){String f=new String(all,start,i-start,StandardCharsets.US_ASCII).trim();if(!f.isEmpty())parseFrame(f);start=i+1;}}if(start>0){acc.reset();acc.write(all,start,all.length-start); } if(acc.size()>16384){byte[] q=acc.toByteArray();acc.reset();acc.write(q,q.length-4096,4096);}}}catch(Exception e){jsState(false,"","Koneksi terputus");}finally{closeSocket();}}
  private void parseFrame(String raw){int idx=raw.toLowerCase(Locale.US).indexOf("a603;");if(idx<0)return;String f=raw.substring(idx);String[] p=f.split(";");if(p.length<13)return;try{int tpsRaw=Integer.parseInt(p[1].trim());int rpm=Integer.parseInt(p[4].trim());double bat=Double.parseDouble(p[2].trim());double eot=Double.parseDouble(p[5].trim())/10.0;double afr=Double.parseDouble(p[7].trim());double inj=Double.parseDouble(p[9].trim());double ign=Double.parseDouble(p[10].trim())/10.0;double mapRaw=Double.parseDouble(p[11].trim());double iat=Double.parseDouble(p[12].trim())/10.0;int tps=tpsRaw<=0?0:(tpsRaw==1?5:(tpsRaw<=19?tpsRaw*5-5:100));int map=(int)Math.max(0,Math.min(100,mapRaw*5.0/1023.0*20));String j=String.format(Locale.US,"{\"rpm\":%d,\"tps\":%d,\"afr\":%.3f,\"bat\":%.3f,\"eot\":%.2f,\"iat\":%.2f,\"inj\":%.2f,\"ign\":%.2f,\"map\":%d,\"raw\":\"%s\"}",rpm,tps,afr,bat,eot,iat,inj,ign,map,esc(f));runOnUiThread(()->web.evaluateJavascript("window.onJukenLive&&window.onJukenLive("+j+")",null));}catch(Exception ignored){}}
  private synchronized void sendRaw(String s){try{if(out!=null){out.write(s.getBytes(StandardCharsets.US_ASCII));out.flush();}}catch(Exception ignored){}}
  private synchronized void closeSocket(){stopRead.set(true);try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;in=null;out=null;}
  @Override protected void onDestroy(){sendRaw("160B\r\n");closeSocket();super.onDestroy();}

  public class JsBridge{
    @JavascriptInterface public String listPaired(){return paired();}
    @JavascriptInterface public void connect(String address){MainActivity.this.connect(address);}
    @JavascriptInterface public void disconnect(){closeSocket();jsState(false,"","Disconnected");}
    @JavascriptInterface public void startLive(){MainActivity.this.startLive();}
    @JavascriptInterface public void send(String command){sendRaw(command==null?"":command);}
    @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
  }
}
