# RNAUTOMAP V10

Direct Bluetooth Classic SPP build. The calculator keeps the previous HTML calculation core and adds the new V10 UI, Base Fuel Map, Base Ignition Map, live dashboard, correction table, monitor, guide, AI helper, and Bluetooth device selection.

Bluetooth protocol note: connection is implemented; live parser only accepts the currently observed `A603;...` frame shape when a complete newline-delimited frame is received. Unknown/malformed frames remain visible in RAW Bluetooth and are not converted into fake values. ECU map write is intentionally not enabled until the JUKEN write protocol is verified.
