RNAUTOMAP JUKEN V8
Companion mode: original JUKEN app remains the ECU/Bluetooth communicator. RNAUTOMAP reads visible JUKEN live data through Android Accessibility. No direct ECU map-write protocol is included.
